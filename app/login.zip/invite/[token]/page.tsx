// app/invite/[token]/page.tsx
import { createClient } from '@/lib/supabase/server';
import { notFound } from 'next/navigation';
import WeddingLandingPage from './WeddingLandingPage';

interface PageProps {
  params: Promise<{
    token: string;
  }>;
}

export default async function InvitationPage({ params }: PageProps) {
  const { token } = await params;
  const supabase = await createClient();

  const { data: guest, error } = await supabase
    .from('guests')
    .select(`
      id,
      name,
      allowed_guests,
      invited_events,
      personal_message,
      token,
      wedding:weddings (
        groom_name,
        bride_name,
        mehndi_date,
        mehndi_time,
        mehndi_venue,
        mehndi_map_url,
        barat_date,
        barat_time,
        barat_venue,
        barat_map_url,
        walima_date,
        walima_time,
        walima_venue,
        walima_map_url,
        groom_family_members,
        contact_person_1,
        contact_number_1,
        contact_person_2,
        contact_number_2
      )
    `)
    .eq('token', token)
    .single();

  if (error || !guest) {
    notFound();
  }

  return <WeddingLandingPage guest={guest as any} />;
}